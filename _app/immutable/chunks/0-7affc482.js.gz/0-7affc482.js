import{_ as t}from"./_layout-8d2a742b.js";import{default as m}from"../components/pages/_layout.svelte-cba69f32.js";import"./index-e8b844da.js";export{m as component,t as shared};
