import{_ as r}from"./_page-bab5f54e.js";import{default as t}from"../components/pages/R1/_page.svelte-3022b63a.js";export{t as component,r as universal};
