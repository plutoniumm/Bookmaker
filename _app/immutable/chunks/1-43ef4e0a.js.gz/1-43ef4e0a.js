import{default as m}from"../components/pages/_error.svelte-03e23f74.js";import"./index-e8b844da.js";export{m as component};
