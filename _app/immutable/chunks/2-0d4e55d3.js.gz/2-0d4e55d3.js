import{default as t}from"../components/pages/_page.svelte-033fbd79.js";export{t as component};
