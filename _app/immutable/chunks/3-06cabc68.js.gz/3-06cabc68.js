import{_ as r}from"./_page-bab5f54e.js";import{default as t}from"../components/pages/R1/_page.svelte-6a21bd3e.js";export{t as component,r as shared};
