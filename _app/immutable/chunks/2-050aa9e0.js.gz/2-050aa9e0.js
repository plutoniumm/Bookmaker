import{default as t}from"../components/pages/_page.svelte-ebb042c2.js";export{t as component};
