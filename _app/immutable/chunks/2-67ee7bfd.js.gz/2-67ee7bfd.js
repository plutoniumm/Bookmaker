import{default as t}from"../components/pages/_page.svelte-1af645d7.js";export{t as component};
