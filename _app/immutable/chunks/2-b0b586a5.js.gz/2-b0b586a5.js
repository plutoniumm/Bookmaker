import{_ as t}from"./_layout-e87908c1.js";import{default as m}from"../components/pages/_slug_/_layout.svelte-eea94f2a.js";import"./index-e8b844da.js";export{m as component,t as shared};
