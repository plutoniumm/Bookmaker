import{default as t}from"../components/pages/_error.svelte-446ad9d5.js";export{t as component};
