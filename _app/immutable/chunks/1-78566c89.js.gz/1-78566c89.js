import{default as t}from"../components/pages/_error.svelte-d6e32ec7.js";export{t as component};
