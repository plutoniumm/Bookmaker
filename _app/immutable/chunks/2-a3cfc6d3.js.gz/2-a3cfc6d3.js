import{default as t}from"../components/pages/_page.svelte-3f1ad45f.js";export{t as component};
