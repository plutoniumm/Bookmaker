import{_ as r}from"./_page-2be92c82.js";import{default as t}from"../components/pages/_slug_/_page.svelte-00fcc685.js";export{t as component,r as shared};
