import{default as t}from"../components/pages/_page.svelte-ca8f3d18.js";export{t as component};
