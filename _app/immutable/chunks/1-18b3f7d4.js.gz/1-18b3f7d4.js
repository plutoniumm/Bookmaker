import{default as t}from"../components/pages/_error.svelte-e4cb2989.js";export{t as component};
