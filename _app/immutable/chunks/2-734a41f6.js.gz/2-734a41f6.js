import{default as t}from"../components/pages/_page.svelte-dfd728a7.js";export{t as component};
