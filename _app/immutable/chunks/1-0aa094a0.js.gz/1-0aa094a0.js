import{default as t}from"../components/pages/_error.svelte-cd04f6ad.js";export{t as component};
