import{_ as r}from"./_page-c60853fe.js";import{default as t}from"../components/pages/_page.svelte-cc79ff8c.js";export{t as component,r as shared};
