import{_ as t}from"./_layout-8d2a742b.js";import{default as m}from"../components/pages/_layout.svelte-3330d2b6.js";import"./index-00fc9565.js";export{m as component,t as shared};
