import{default as t}from"../components/pages/_page.svelte-23f473dc.js";export{t as component};
