import{default as t}from"../components/pages/_error.svelte-ce43adef.js";export{t as component};
