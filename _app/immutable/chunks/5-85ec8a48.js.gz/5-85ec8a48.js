import{_ as t}from"./_page-d84940a5.js";import{default as m}from"../components/pages/books/R1/_page.svelte-a078805c.js";import"./index-e8b844da.js";export{m as component,t as shared};
