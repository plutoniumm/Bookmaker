import{_ as t}from"./_layout-8d2a742b.js";import{default as m}from"../components/pages/_layout.svelte-99e8d8b7.js";import"./index-23535c31.js";export{m as component,t as shared};
