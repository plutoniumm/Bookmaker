import{_ as r}from"./_page-55d2c0b9.js";import{default as t}from"../components/pages/R1/_page.svelte-7a3887fb.js";export{t as component,r as shared};
