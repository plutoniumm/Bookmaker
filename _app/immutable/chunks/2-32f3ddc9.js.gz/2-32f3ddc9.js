import{default as t}from"../components/pages/_page.svelte-61069e10.js";export{t as component};
