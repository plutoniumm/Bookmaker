import{default as t}from"../components/pages/_error.svelte-f783a847.js";export{t as component};
