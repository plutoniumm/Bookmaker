import{default as t}from"../components/pages/_error.svelte-f7402d92.js";export{t as component};
