import{default as t}from"../components/pages/_error.svelte-883e34cb.js";export{t as component};
