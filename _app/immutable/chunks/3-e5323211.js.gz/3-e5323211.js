import{_ as r}from"./_page-55d2c0b9.js";import{default as t}from"../components/pages/R1/_page.svelte-e80f2644.js";export{t as component,r as shared};
