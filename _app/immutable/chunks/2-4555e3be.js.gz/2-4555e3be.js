import{default as t}from"../components/pages/_page.svelte-2d14374f.js";export{t as component};
