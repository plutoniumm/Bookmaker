import{default as t}from"../components/pages/_error.svelte-3cf7f47b.js";export{t as component};
