import{_ as r}from"./_page-c60853fe.js";import{default as t}from"../components/pages/_page.svelte-506822ce.js";export{t as component,r as shared};
