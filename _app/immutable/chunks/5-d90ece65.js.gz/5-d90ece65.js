import{_ as r}from"./_page-d84940a5.js";import{default as t}from"../components/pages/books/R1/_page.svelte-b70b5b72.js";export{t as component,r as shared};
