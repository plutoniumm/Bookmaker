import{_ as t}from"./_layout-e87908c1.js";import{default as m}from"../components/pages/_slug_/_layout.svelte-cb986560.js";import"./index-00fc9565.js";export{m as component,t as shared};
