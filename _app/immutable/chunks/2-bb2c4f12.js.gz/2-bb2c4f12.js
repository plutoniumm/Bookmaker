import{_ as r}from"./_layout-e87908c1.js";import{default as t}from"../components/pages/_slug_/_layout.svelte-5487ac65.js";export{t as component,r as shared};
