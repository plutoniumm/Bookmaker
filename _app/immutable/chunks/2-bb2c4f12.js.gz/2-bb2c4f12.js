import{_ as t}from"./_layout-e87908c1.js";import{default as m}from"../components/pages/_slug_/_layout.svelte-5487ac65.js";import"./index-23535c31.js";export{m as component,t as shared};
