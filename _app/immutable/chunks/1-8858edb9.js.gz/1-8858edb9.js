import{default as m}from"../components/pages/_error.svelte-babbcae2.js";import"./index-00fc9565.js";export{m as component};
