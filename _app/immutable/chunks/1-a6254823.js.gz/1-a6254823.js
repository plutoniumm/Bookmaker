import{default as t}from"../components/pages/_error.svelte-1f2eccad.js";export{t as component};
