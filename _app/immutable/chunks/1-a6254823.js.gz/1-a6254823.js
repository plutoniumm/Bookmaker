import{default as m}from"../components/pages/_error.svelte-1f2eccad.js";import"./index-23535c31.js";export{m as component};
