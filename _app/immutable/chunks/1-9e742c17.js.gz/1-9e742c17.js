import{default as t}from"../components/pages/_error.svelte-ad15c180.js";export{t as component};
