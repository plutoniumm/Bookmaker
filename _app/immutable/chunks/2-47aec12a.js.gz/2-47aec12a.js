import{default as t}from"../components/pages/_page.svelte-62ac31f9.js";export{t as component};
