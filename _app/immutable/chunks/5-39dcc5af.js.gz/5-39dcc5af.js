import{_ as t}from"./_page-d84940a5.js";import{default as m}from"../components/pages/books/R1/_page.svelte-83ccec70.js";import"./index-23535c31.js";export{m as component,t as shared};
