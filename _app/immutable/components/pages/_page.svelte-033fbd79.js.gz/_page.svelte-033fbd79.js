import{S as T,i as y,s as E,k as h,r as g,a as b,l as f,m as p,u as m,h as o,c as C,p as v,b as H,C as r,n as d}from"../../chunks/index-dec82b63.js";function I(x){let e,s,i,l,t,c;return{c(){e=h("section"),s=h("h3"),i=g(`What's Happening?: This page is for testing of web features and not for
		usage. This is a remenant of the first ever large scale project I
		created.`),l=b(),t=h("a"),c=g("Round 1"),this.h()},l(n){e=f(n,"SECTION",{});var a=p(e);s=f(a,"H3",{});var _=p(s);i=m(_,`What's Happening?: This page is for testing of web features and not for
		usage. This is a remenant of the first ever large scale project I
		created.`),_.forEach(o),l=C(a),t=f(a,"A",{class:!0,href:!0});var u=p(t);c=m(u,"Round 1"),u.forEach(o),a.forEach(o),this.h()},h(){v(t,"class","p10 rx10  svelte-kfrate"),v(t,"href","/R1")},m(n,a){H(n,e,a),r(e,s),r(s,i),r(e,l),r(e,t),r(t,c)},p:d,i:d,o:d,d(n){n&&o(e)}}}class S extends T{constructor(e){super(),y(this,e,null,I,E,{})}}export{S as default};
