import{S as T,i as b,s as y,k as h,r as g,a as E,l as f,m as p,u as m,h as o,c as H,p as v,b as I,D as r,n as d}from"../../chunks/index-a4916006.js";function R(x){let e,s,i,l,t,c;return{c(){e=h("section"),s=h("h3"),i=g(`What's Happening?: This page is for testing of web features and not for
		usage. This is a remenant of the first ever large scale project I
		created.`),l=E(),t=h("a"),c=g("Round 1"),this.h()},l(n){e=f(n,"SECTION",{});var a=p(e);s=f(a,"H3",{});var _=p(s);i=m(_,`What's Happening?: This page is for testing of web features and not for
		usage. This is a remenant of the first ever large scale project I
		created.`),_.forEach(o),l=H(a),t=f(a,"A",{class:!0,href:!0});var u=p(t);c=m(u,"Round 1"),u.forEach(o),a.forEach(o),this.h()},h(){v(t,"class","p10 rx5 bgf svelte-vaaa6s"),v(t,"href","/R1")},m(n,a){I(n,e,a),r(e,s),r(s,i),r(e,l),r(e,t),r(t,c)},p:d,i:d,o:d,d(n){n&&o(e)}}}class j extends T{constructor(e){super(),b(this,e,null,R,y,{})}}export{j as default};
