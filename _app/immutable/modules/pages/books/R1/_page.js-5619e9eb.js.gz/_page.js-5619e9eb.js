import{l}from"../../../../chunks/_page-d84940a5.js";export{l as load};
