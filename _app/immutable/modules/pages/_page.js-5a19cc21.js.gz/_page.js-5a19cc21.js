import{l}from"../../chunks/_page-c60853fe.js";export{l as load};
