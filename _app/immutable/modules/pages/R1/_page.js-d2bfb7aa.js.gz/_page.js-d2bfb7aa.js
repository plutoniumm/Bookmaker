import{l}from"../../../chunks/_page-bab5f54e.js";export{l as load};
