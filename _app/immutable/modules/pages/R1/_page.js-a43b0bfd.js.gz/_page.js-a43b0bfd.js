import{l}from"../../../chunks/_page-55d2c0b9.js";export{l as load};
