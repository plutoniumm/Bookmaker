import"../../../chunks/preload-helper-aa6bc0ce.js";import{l}from"../../../chunks/_page-2be92c82.js";export{l as load};
