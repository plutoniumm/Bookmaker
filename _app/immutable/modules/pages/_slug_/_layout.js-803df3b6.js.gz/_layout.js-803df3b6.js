import{p}from"../../../chunks/_layout-e87908c1.js";export{p as prerender};
